﻿namespace RemService
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            loginTextBox = new TextBox();
            passwordTextBox = new TextBox();
            signUpHeading = new Label();
            signUpBtn = new Button();
            passCheckBtn = new Button();
            signUpErrorLabel = new Label();
            SuspendLayout();
            // 
            // loginTextBox
            // 
            loginTextBox.Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point);
            loginTextBox.Location = new Point(139, 86);
            loginTextBox.Name = "loginTextBox";
            loginTextBox.PlaceholderText = "Логін";
            loginTextBox.Size = new Size(214, 26);
            loginTextBox.TabIndex = 0;
            loginTextBox.TextChanged += loginTextBox_TextChanged;
            // 
            // passwordTextBox
            // 
            passwordTextBox.Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point);
            passwordTextBox.Location = new Point(139, 141);
            passwordTextBox.Name = "passwordTextBox";
            passwordTextBox.PlaceholderText = "Пароль";
            passwordTextBox.Size = new Size(180, 26);
            passwordTextBox.TabIndex = 1;
            passwordTextBox.UseSystemPasswordChar = true;
            passwordTextBox.TextChanged += passwordTextBox_TextChanged;
            // 
            // signUpHeading
            // 
            signUpHeading.AutoSize = true;
            signUpHeading.Font = new Font("Century Gothic", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            signUpHeading.Location = new Point(75, 18);
            signUpHeading.Name = "signUpHeading";
            signUpHeading.Size = new Size(339, 27);
            signUpHeading.TabIndex = 2;
            signUpHeading.Text = "Вхід до особистого кабінету";
            // 
            // signUpBtn
            // 
            signUpBtn.Location = new Point(186, 200);
            signUpBtn.Name = "signUpBtn";
            signUpBtn.Size = new Size(124, 34);
            signUpBtn.TabIndex = 3;
            signUpBtn.Text = "Вхід";
            signUpBtn.UseVisualStyleBackColor = true;
            signUpBtn.Click += signUpBtn_Click;
            // 
            // passCheckBtn
            // 
            passCheckBtn.Location = new Point(325, 141);
            passCheckBtn.Name = "passCheckBtn";
            passCheckBtn.Size = new Size(28, 26);
            passCheckBtn.TabIndex = 4;
            passCheckBtn.Text = "O";
            passCheckBtn.UseVisualStyleBackColor = true;
            passCheckBtn.Click += passCheckBtn_Click;
            // 
            // signUpErrorLabel
            // 
            signUpErrorLabel.AutoSize = true;
            signUpErrorLabel.ForeColor = Color.Red;
            signUpErrorLabel.Location = new Point(127, 269);
            signUpErrorLabel.Name = "signUpErrorLabel";
            signUpErrorLabel.Size = new Size(239, 20);
            signUpErrorLabel.TabIndex = 5;
            signUpErrorLabel.Text = "Неправильний логін або пароль";
            signUpErrorLabel.Visible = false;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(485, 350);
            Controls.Add(signUpErrorLabel);
            Controls.Add(passCheckBtn);
            Controls.Add(signUpBtn);
            Controls.Add(signUpHeading);
            Controls.Add(passwordTextBox);
            Controls.Add(loginTextBox);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            Name = "Form1";
            Text = "Вхід";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox loginTextBox;
        private TextBox passwordTextBox;
        private Label label1;
        private Button signUpBtn;
        private Button passCheckBtn;
        private Label signUpErrorLabel;
        public Label signUpHeading;
    }
}
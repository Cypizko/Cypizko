using System.Runtime.InteropServices;

namespace RemService
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }



        private void passCheckBtn_Click(object sender, EventArgs e)
        {
            if (passwordTextBox.UseSystemPasswordChar == false)
            {
                passwordTextBox.UseSystemPasswordChar = true;
                passCheckBtn.Text = "O";
            }
            else
            {
                passwordTextBox.UseSystemPasswordChar = false;
                passCheckBtn.Text = "-";
            }

        }

        private void signUpBtn_Click(object sender, EventArgs e)
        {
            if (loginTextBox.Text == "admin" && passwordTextBox.Text == "1111")
            {
                Form Main = new RemService();
                Main.Show();
                this.Hide();
            }
            else
            {
                signUpErrorLabel.Visible = true;
            }

        }

        private void loginTextBox_TextChanged(object sender, EventArgs e)
        {
            signUpErrorLabel.Visible = false;
        }

        private void passwordTextBox_TextChanged(object sender, EventArgs e)
        {
            signUpErrorLabel.Visible = false;
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.IO;

namespace RemService
{
    public partial class RemService : Form
    {
        public RemService()
        {
            InitializeComponent();
            LoadDataFromXML();
            PopulateModelsComboBox();
            PopulateMastersComboBox();
        }

        private void Main_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void LoadDataFromXML()
        {
            // Завантаження XML-файлу
            XmlDocument doc = new XmlDocument();
            doc.Load(@"..\..\..\XML\XML.xml");


            // Заповнення DataTable даними з XML
            XmlNodeList invoices = doc.SelectNodes("/root/invoice");

            foreach (XmlNode invoice in invoices)
            {
                // Створення нового рядка
                DataGridViewRow row = new DataGridViewRow();
                row.CreateCells(invoicesDGV);

                // Заповнення даними
                row.Cells[0].Value = int.Parse(invoice.Attributes["number"].Value);
                row.Cells[1].Value = invoice["model"].InnerText;

                decimal detailPrice = decimal.Parse(invoice["detailPrice"].InnerText);
                decimal workPrice = decimal.Parse(invoice["workPrice"].InnerText);
                decimal fullPrice = detailPrice + workPrice;

                row.Cells[2].Value = detailPrice.ToString("N0", CultureInfo.InvariantCulture) + " грн";
                row.Cells[3].Value = workPrice.ToString("N0", CultureInfo.InvariantCulture) + " грн";
                row.Cells[4].Value = fullPrice.ToString("N0", CultureInfo.InvariantCulture) + " грн";
                row.Cells[5].Value = invoice["date"].InnerText;
                row.Cells[6].Value = invoice["master"].InnerText;

                // Додавання рядка до DataGridView
                invoicesDGV.Rows.Add(row);
            }
        }

        private void addBtn_Click(object sender, EventArgs e)
        {
            if (modelTextBox.Text == "" || detailPriceTextBox.Text == "" || workPriceTextBox.Text == "" || dateTextBox.Text == "" || masterTextBox.Text == "")
            {
                MessageBox.Show("Заповніть всі поля.", "Помилка");
            }
            else
            {
                try
                {
                    // Зчитування значень з текстових полів
                    string model = modelTextBox.Text;
                    decimal detailPrice = decimal.Parse(detailPriceTextBox.Text);
                    decimal workPrice = decimal.Parse(workPriceTextBox.Text);
                    string date = dateTextBox.Text;
                    string master = masterTextBox.Text;

                    // Обчислення нового значення для numberColumn
                    int maxNumber = 0;
                    if (invoicesDGV.Rows.Count > 0)
                    {
                        maxNumber = invoicesDGV.Rows.Cast<DataGridViewRow>()
                                       .Max(r => Convert.ToInt32(r.Cells["numberColumn"].Value));
                    }
                    int newNumber = maxNumber + 1;

                    // Обчислення повної ціни
                    decimal fullPrice = detailPrice + workPrice;

                    // Форматування значень
                    string formattedDetailPrice = detailPrice.ToString("N0", CultureInfo.InvariantCulture) + " грн";
                    string formattedWorkPrice = workPrice.ToString("N0", CultureInfo.InvariantCulture) + " грн";
                    string formattedFullPrice = fullPrice.ToString("N0", CultureInfo.InvariantCulture) + " грн";

                    // Створення нового рядка
                    DataGridViewRow row = new DataGridViewRow();
                    row.CreateCells(invoicesDGV);

                    row.Cells[0].Value = newNumber;
                    row.Cells[1].Value = model;
                    row.Cells[2].Value = formattedDetailPrice;
                    row.Cells[3].Value = formattedWorkPrice;
                    row.Cells[4].Value = formattedFullPrice;
                    row.Cells[5].Value = date;
                    row.Cells[6].Value = master;

                    // Додавання нового рядка до DataGridView
                    invoicesDGV.Rows.Add(row);

                    // Очищення текстових полів
                    modelTextBox.Clear();
                    detailPriceTextBox.Clear();
                    workPriceTextBox.Clear();
                    dateTextBox.Clear();
                    masterTextBox.Clear();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("При створенні накладної відбулася помилка: " + ex.Message);
                }
            }
        }

        private void redBtn_Click(object sender, EventArgs e)
        {
            try
            {
                // Перевірка, чи вибраний рядок
                if (invoicesDGV.SelectedRows.Count == 0)
                {
                    MessageBox.Show("Будь ласка, виберіть рядок для редагування.");
                    return;
                }

                // Зчитування значень з текстових полів
                string model = modelTextBox.Text;
                decimal detailPrice = decimal.Parse(detailPriceTextBox.Text);
                decimal workPrice = decimal.Parse(workPriceTextBox.Text);
                string date = dateTextBox.Text;
                string master = masterTextBox.Text;

                // Обчислення повної ціни
                decimal fullPrice = detailPrice + workPrice;

                // Форматування значень
                string formattedDetailPrice = detailPrice.ToString("N0", CultureInfo.InvariantCulture) + " грн";
                string formattedWorkPrice = workPrice.ToString("N0", CultureInfo.InvariantCulture) + " грн";
                string formattedFullPrice = fullPrice.ToString("N0", CultureInfo.InvariantCulture) + " грн";

                // Зміна значень вибраного рядка
                DataGridViewRow selectedRow = invoicesDGV.SelectedRows[0];

                selectedRow.Cells["modelColumn"].Value = model;
                selectedRow.Cells["detailPriceColumn"].Value = formattedDetailPrice;
                selectedRow.Cells["workPriceColumn"].Value = formattedWorkPrice;
                selectedRow.Cells["fullPriceColumn"].Value = formattedFullPrice;
                selectedRow.Cells["dateColumn"].Value = date;
                selectedRow.Cells["masterColumn"].Value = master;

                // Очищення текстових полів
                modelTextBox.Clear();
                detailPriceTextBox.Clear();
                workPriceTextBox.Clear();
                dateTextBox.Clear();
                masterTextBox.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Помилка зміни рядка: " + ex.Message);
            }
        }

        private void delBtn_Click(object sender, EventArgs e)
        {
            try
            {
                // Перевірка, чи вибрані рядки
                if (invoicesDGV.SelectedRows.Count == 0)
                {
                    MessageBox.Show("Будь ласка, виберіть рядок для видалення.");
                    return;
                }

                // Видалення вибраних рядків
                foreach (DataGridViewRow row in invoicesDGV.SelectedRows)
                {
                    if (!row.IsNewRow)
                    {
                        invoicesDGV.Rows.Remove(row);
                    }
                }

                // Оновлення номерів накладних
                UpdateInvoiceNumbers();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error deleting invoice: " + ex.Message);
            }
        }

        private void UpdateInvoiceNumbers()
        {
            int number = 1;
            foreach (DataGridViewRow row in invoicesDGV.Rows)
            {
                if (!row.IsNewRow)
                {
                    row.Cells["numberColumn"].Value = number++;
                }
            }
        }

        // Метод для обміну елементів масиву
        private static void Swap(ref int x, ref int y)
        {
            var t = x;
            x = y;
            y = t;
        }

        // Метод повертає індекс опорного елементу
        static int Partition(int[] array, int minIndex, int maxIndex)
        {
            var pivot = minIndex - 1;
            for (var i = minIndex; i < maxIndex; i++)
            {
                if (array[i] < array[maxIndex])
                {
                    pivot++;
                    Swap(ref array[pivot], ref array[i]);
                }
            }

            pivot++;
            Swap(ref array[pivot], ref array[maxIndex]);
            return pivot;
        }

        // Швидке сортування
        static int[] QuickSort(int[] array, int minIndex, int maxIndex)
        {
            if (minIndex >= maxIndex)
            {
                return array;
            }

            var pivotIndex = Partition(array, minIndex, maxIndex);
            QuickSort(array, minIndex, pivotIndex - 1);
            QuickSort(array, pivotIndex + 1, maxIndex);

            return array;
        }

        static int[] QuickSort(int[] array)
        {
            return QuickSort(array, 0, array.Length - 1);
        }
        private void sortBtn_Click(object sender, EventArgs e)
        {
            // Вимикаємо можливість додавання нових рядків
            invoicesDGV.AllowUserToAddRows = false;

            // Зчитування даних з стовпця numberColumn у масив
            int rowCount = invoicesDGV.Rows.Count;
            int[] numbers = new int[rowCount];

            for (int i = 0; i < rowCount; i++)
            {
                numbers[i] = Convert.ToInt32(invoicesDGV.Rows[i].Cells["numberColumn"].Value);
            }

            // Виконання швидкого сортування
            QuickSort(numbers);

            // Створення словника для зберігання рядків по значеннях numberColumn
            var rowDict = invoicesDGV.Rows.Cast<DataGridViewRow>()
                            .ToDictionary(row => Convert.ToInt32(row.Cells["numberColumn"].Value));

            // Очищення DataGridView
            invoicesDGV.Rows.Clear();

            // Додавання рядків відповідно до відсортованого масиву
            foreach (int number in numbers)
            {
                invoicesDGV.Rows.Add(rowDict[number]);
            }

            // Знову дозволяємо додавання нових рядків
            invoicesDGV.AllowUserToAddRows = true;
        }

        private void saveBtn_Click_1(object sender, EventArgs e)
        {
            using (SaveFileDialog saveFileDialog = new SaveFileDialog())
            {
                saveFileDialog.Filter = "XML файли (*.xml)|*.xml|Всі файли (*.*)|*.*";
                saveFileDialog.Title = "Зберегти як";
                saveFileDialog.DefaultExt = "xml";
                saveFileDialog.AddExtension = true;

                string initialDirectory = Path.GetFullPath(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"..\..\..\XML"));
                saveFileDialog.InitialDirectory = initialDirectory;

                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string filePath = saveFileDialog.FileName;
                    SaveDataGridViewToXML(invoicesDGV, filePath);
                }
            }
        }

        private void SaveDataGridViewToXML(DataGridView dgv, string filePath)
        {
            try
            {
                using (XmlWriter writer = XmlWriter.Create(filePath, new XmlWriterSettings { Indent = true }))
                {
                    writer.WriteStartDocument();
                    writer.WriteStartElement("root");

                    foreach (DataGridViewRow row in dgv.Rows)
                    {
                        if (!row.IsNewRow)
                        {
                            writer.WriteStartElement("invoice");
                            writer.WriteAttributeString("number", row.Cells["numberColumn"].Value.ToString());

                            writer.WriteElementString("model", row.Cells["modelColumn"].Value.ToString());
                            writer.WriteElementString("detailPrice", row.Cells["detailPriceColumn"].Value.ToString().Replace(" грн", "").Replace(",", ""));
                            writer.WriteElementString("workPrice", row.Cells["workPriceColumn"].Value.ToString().Replace(" грн", "").Replace(",", ""));
                            writer.WriteElementString("date", row.Cells["dateColumn"].Value.ToString());
                            writer.WriteElementString("master", row.Cells["masterColumn"].Value.ToString());

                            writer.WriteEndElement(); // invoice
                        }
                    }

                    writer.WriteEndElement(); // root
                    writer.WriteEndDocument();
                }

                MessageBox.Show("Дані збережено успішно.", "Збереження", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Помилка при збереженні даних: " + ex.Message, "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void clearBtn_Click(object sender, EventArgs e)
        {
            if (invoicesDGV.Rows.Count > 0)
            {
                invoicesDGV.Rows.Clear();
            }
            else
            {
                MessageBox.Show("Таблиця пуста.");
            }

        }

        private void loadBtn_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.Filter = "XML файли (*.xml)|*.xml|Всі файли (*.*)|*.*";
                openFileDialog.Title = "Відкрити файл";
                openFileDialog.InitialDirectory = Path.GetFullPath(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"..\..\..\XML"));

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string filePath = openFileDialog.FileName;
                    LoadDataGridViewFromXML(invoicesDGV, filePath);
                }
            }
        }

        private void LoadDataGridViewFromXML(DataGridView dgv, string filePath)
        {
            try
            {
                dgv.Rows.Clear();
                XmlDocument doc = new XmlDocument();
                doc.Load(filePath);

                XmlNodeList invoiceNodes = doc.SelectNodes("//invoice");
                foreach (XmlNode invoiceNode in invoiceNodes)
                {
                    string number = invoiceNode.Attributes["number"].Value;
                    string model = invoiceNode["model"].InnerText;
                    string detailPrice = invoiceNode["detailPrice"].InnerText;
                    string workPrice = invoiceNode["workPrice"].InnerText;
                    string date = invoiceNode["date"].InnerText;
                    string master = invoiceNode["master"].InnerText;
                    decimal detailPriceValue = decimal.Parse(detailPrice);
                    decimal workPriceValue = decimal.Parse(workPrice);
                    decimal fullPriceValue = detailPriceValue + workPriceValue;

                    string formattedDetailPrice = detailPriceValue.ToString("N0", CultureInfo.InvariantCulture) + " грн";
                    string formattedWorkPrice = workPriceValue.ToString("N0", CultureInfo.InvariantCulture) + " грн";
                    string formattedFullPrice = fullPriceValue.ToString("N0", CultureInfo.InvariantCulture) + " грн";

                    dgv.Rows.Add(number, model, formattedDetailPrice, formattedWorkPrice, formattedFullPrice, date, master);
                }

                MessageBox.Show("Дані завантажено успішно.", "Завантаження", MessageBoxButtons.OK, MessageBoxIcon.Information);

                PopulateModelsComboBox();
                PopulateMastersComboBox();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Помилка при завантаженні даних: " + ex.Message, "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void findBtn_Click(object sender, EventArgs e)
        {
            if (modelRBtn.Checked)
            {
                if (modelsComboBox.SelectedItem != null)
                {
                    string modelToFind = modelsComboBox.SelectedItem.ToString().Trim();

                    // Очистити результуючу таблицю
                    findDGV.Rows.Clear();

                    // Знайти всі рядки, що відповідають моделі
                    var matchingRows = invoicesDGV.Rows
                        .Cast<DataGridViewRow>()
                        .Where(row => !row.IsNewRow && row.Cells["modelColumn"].Value.ToString().Equals(modelToFind, StringComparison.OrdinalIgnoreCase))
                        .ToList();

                    // Додати знайдені рядки до findDGV з новими номерами
                    int newInvoiceNumber = 1;
                    foreach (var row in matchingRows)
                    {
                        var rowData = row.Cells.Cast<DataGridViewCell>().Select(cell => cell.Value).ToArray();
                        rowData[0] = newInvoiceNumber.ToString(); // Зміна номера накладної
                        findDGV.Rows.Add(rowData);
                        newInvoiceNumber++;
                    }
                }
                else
                {
                    MessageBox.Show("Будь ласка, оберіть модель з випадаючого списку.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else if (highPriceRBtn.Checked)
            {
                // Очистити результуючу таблицю
                findDGV.Rows.Clear();

                // Знайти всі рядки
                var allRows = invoicesDGV.Rows
                    .Cast<DataGridViewRow>()
                    .Where(row => !row.IsNewRow)
                    .ToList();

                // Отримати масив повних цін
                var fullPrices = allRows
                    .Select(row => int.Parse(row.Cells["fullPriceColumn"].Value.ToString().Replace(" грн", "").Replace(",", "")))
                    .ToArray();

                // Використовувати швидке сортування для сортування цін
                QuickSort(fullPrices);

                // Знайти топ-5 найдорожчих ремонтів
                var top5Prices = fullPrices.Reverse().Take(5).ToList();

                // Додати топ-5 рядків до findDGV з новими номерами
                int newInvoiceNumber = 1;
                foreach (var price in top5Prices)
                {
                    var row = allRows.First(r =>
                        int.Parse(r.Cells["fullPriceColumn"].Value.ToString().Replace(" грн", "").Replace(",", "")) == price);
                    allRows.Remove(row); // Remove row to handle duplicate prices correctly

                    var rowData = row.Cells.Cast<DataGridViewCell>().Select(cell => cell.Value).ToArray();
                    rowData[0] = newInvoiceNumber.ToString(); // Зміна номера накладної
                    findDGV.Rows.Add(rowData);
                    newInvoiceNumber++;
                }
            }
            else if (masterRBtn.Checked)
            {
                if (masterComboBox.SelectedItem != null)
                {
                    string selectedMaster = masterComboBox.SelectedItem.ToString();

                    // Очистити результуючу таблицю
                    findDGV.Rows.Clear();

                    // Знайти всі роботи майстра
                    var matchingRows = invoicesDGV.Rows
                        .Cast<DataGridViewRow>()
                        .Where(row => !row.IsNewRow && row.Cells["masterColumn"].Value.ToString().Equals(selectedMaster, StringComparison.OrdinalIgnoreCase))
                        .ToList();

                    // Додати знайдені рядки до findDGV з новими номерами
                    int newInvoiceNumber = 1;
                    foreach (var row in matchingRows)
                    {
                        var rowData = row.Cells.Cast<DataGridViewCell>().Select(cell => cell.Value).ToArray();
                        rowData[0] = newInvoiceNumber.ToString(); // Зміна номера накладної
                        findDGV.Rows.Add(rowData);
                        newInvoiceNumber++;
                    }
                }
                else
                {
                    MessageBox.Show("Будь ласка, оберіть майстра з випадаючого списку.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else if (dateRBtn.Checked)
            {
                // Перевірка правильності формату дат
                DateTime firstDate, secondDate;
                if (!DateTime.TryParseExact(firstDateTextBox.Text, "dd.MM.yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out firstDate) ||
                    !DateTime.TryParseExact(secondDateTextBox.Text, "dd.MM.yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out secondDate))
                {
                    MessageBox.Show("Будь ласка, введіть дати у форматі 'dd.MM.yyyy'.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Очистити результуючі елементи
                findDGV.Rows.Clear();
                resultDateTextBox.Clear();

                // Обчислення суми вартості всіх деталей ремонту за зазначений період
                int totalDetailCost = 0;
                foreach (DataGridViewRow row in invoicesDGV.Rows)
                {
                    if (!row.IsNewRow)
                    {
                        DateTime invoiceDate;
                        if (DateTime.TryParseExact(row.Cells["dateColumn"].Value.ToString(), "dd.MM.yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out invoiceDate))
                        {
                            // Перевірка, чи дата накладної потрапляє в зазначений період
                            if (invoiceDate >= firstDate && invoiceDate <= secondDate)
                            {
                                // Додати вартість деталей ремонту до загальної суми
                                totalDetailCost += Convert.ToInt32(row.Cells["detailPriceColumn"].Value.ToString().Replace(" грн", "").Replace(",", "").Trim());
                            }
                        }
                    }
                }

                // Виведення суми вартості всіх деталей ремонту
                resultDateTextBox.Text = totalDetailCost.ToString();

                // Виведення всіх накладних, зроблених за зазначений період
                foreach (DataGridViewRow row in invoicesDGV.Rows)
                {
                    if (!row.IsNewRow)
                    {
                        DateTime invoiceDate;
                        if (DateTime.TryParseExact(row.Cells["dateColumn"].Value.ToString(), "dd.MM.yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out invoiceDate))
                        {
                            // Перевірка, чи дата накладної потрапляє в зазначений період
                            if (invoiceDate >= firstDate && invoiceDate <= secondDate)
                            {
                                // Додати рядок у findDGV
                                findDGV.Rows.Add(row.Cells.Cast<DataGridViewCell>().Select(cell => cell.Value).ToArray());
                            }
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Будь ласка, оберіть критерій пошуку.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

        }

        private void PopulateModelsComboBox()
        {
            // Отримати унікальні моделі з invoicesDGV
            var uniqueModels = invoicesDGV.Rows
                .Cast<DataGridViewRow>()
                .Where(row => !row.IsNewRow)
                .Select(row => row.Cells["modelColumn"].Value.ToString())
                .Distinct()
                .ToList();

            // Очистити ComboBox перед додаванням нових елементів
            modelsComboBox.Items.Clear();

            // Додати унікальні моделі до ComboBox
            foreach (var model in uniqueModels)
            {
                modelsComboBox.Items.Add(model);
            }
        }

        private void modelsComboBox_DropDown(object sender, EventArgs e)
        {
            PopulateModelsComboBox();
        }

        private void PopulateMastersComboBox()
        {
            // Отримати унікальні імена майстрів з invoicesDGV
            var uniqueMasters = invoicesDGV.Rows
                .Cast<DataGridViewRow>()
                .Where(row => !row.IsNewRow)
                .Select(row => row.Cells["masterColumn"].Value.ToString())
                .Distinct()
                .ToList();

            // Очистити ComboBox перед додаванням нових елементів
            masterComboBox.Items.Clear();

            // Додати унікальні імена майстрів до ComboBox
            foreach (var master in uniqueMasters)
            {
                masterComboBox.Items.Add(master);
            }
        }

        private void MasterComboBox_DropDown(object sender, EventArgs e)
        {
            PopulateMastersComboBox();
        }

    }
}
